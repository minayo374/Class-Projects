
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class SOSDriver {
    private JFrame frame;
    private JButton[][] buttons;
    private JRadioButton blueS, blueO, redS, redO, simpleGame, generalGame;
    private JTextField boardSize;
    private SOSBoard boardPanel;
    private JLabel currentTurnLabel;
    private int n = 5;
    private String winner = null;
    private String currentPlayer = "blue";
    

    public SOSDriver() {
        frame = new JFrame("SOS Game");
        frame.setSize(600, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        boardPanel = new SOSBoard(5);
        

        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("SOS"));
        simpleGame = new JRadioButton("Simple game", true);
        generalGame = new JRadioButton("General game");
        ButtonGroup gameModeGroup = new ButtonGroup();
        gameModeGroup.add(simpleGame);
        gameModeGroup.add(generalGame);
        topPanel.add(simpleGame);
        topPanel.add(generalGame);
        topPanel.add(new JLabel("Board size"));
        boardSize = new JTextField(2);
        boardSize.setText(String.valueOf(n));
        topPanel.add(boardSize);

        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new GridLayout(3, 1));
        leftPanel.add(new JLabel("Blue player"));
        blueS = new JRadioButton("S", true);
        blueO = new JRadioButton("O");
        ButtonGroup blueGroup = new ButtonGroup();
        blueGroup.add(blueS);
        blueGroup.add(blueO);
        leftPanel.add(blueS);
        leftPanel.add(blueO);
        
        blueS.addActionListener(new RadioButtonListener());
        blueO.addActionListener(new RadioButtonListener());

        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new GridLayout(3, 1));
        rightPanel.add(new JLabel("Red player"));
        redS = new JRadioButton("S", true);
        redO = new JRadioButton("O");
        ButtonGroup redGroup = new ButtonGroup();
        redGroup.add(redS);
        redGroup.add(redO);
        rightPanel.add(redS);
        rightPanel.add(redO);
        
        redS.addActionListener(new RadioButtonListener());
        redO.addActionListener(new RadioButtonListener());

        currentTurnLabel = boardPanel.currentTurnLabel;
        frame.add(topPanel, BorderLayout.NORTH);
        frame.add(leftPanel, BorderLayout.WEST);
        frame.add(rightPanel, BorderLayout.EAST);
        frame.add(boardPanel, BorderLayout.CENTER);
        frame.add(currentTurnLabel, BorderLayout.SOUTH);

        frame.setVisible(true);
    }
    
        
    

    private class RadioButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
        	if (e.getSource() == simpleGame) {
                // Handle selection of the Simple game mode
                // You can add any specific logic here
            } else if (e.getSource() == generalGame) {
                // Handle selection of the General game mode
                // You can add any specific logic here
            }

            // Handle player selection
            if (e.getSource() == blueS) {
                boardPanel.isBlueS = true;
                currentPlayer = "blue";
            } else if (e.getSource() == blueO) {
                boardPanel.isBlueS = false;
                currentPlayer = "blue";
            } else if (e.getSource() == redS) {
                boardPanel.isRedS = true;
                currentPlayer = "red";
            } else if (e.getSource() == redO) {
                boardPanel.isRedS = false;
                currentPlayer = "red";
            }
        	
            // For instance, maybe clear the board if the game mode changes
        }
    }
   
    
    

//    public void checkForWin(int x, int y) {
//        // Check rows, columns, and diagonals for SOS
//        if (checkDirection(x, y, 1, 0) || checkDirection(x, y, 0, 1) || checkDirection(x, y, 1, 1) || checkDirection(x, y, 1, -1)) {
//            winner = currentPlayer;
//            JOptionPane.showMessageDialog(frame, winner + " wins!");
//            resetGame();
//        }
//    }

//    public boolean checkDirection(int x, int y, int dx, int dy) {
//        if (x + dx >= n || x + dx < 0 || y + dy >= n || y + dy < 0) {return false;}
//        String text = buttons[x][y].getText();
//        
//        //if the input text is S, look for "OS" 
//        if (text.equals("S")){
//        	if(x + 1 ) {
//        		if(buttons[x + 1][y].equals("O") && buttons[x + 2][y].equals("S")) {return true;}
//        	}
//        }
//        //if the input is look for "S"s
//        else if (text.equals("O")) {
//        	
//        }
//        
//        return false;
//    }

    public void resetGame() {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                buttons[i][j].setText("");
            }
        }
        currentPlayer = "S";
        winner = null;
    }

    


public static void main (String[] args) {
	new SOSDriver();
}}
    
   
   