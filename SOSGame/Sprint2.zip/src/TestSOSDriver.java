import static org.junit.Assert.*;

import javax.swing.JButton;

import org.junit.Test;

public class TestSOSDriver {

	
	@Test
	public void testBoardSize5() {
		SOSBoard board = new SOSBoard(5);
		int col = board.buttons.length;
		assertEquals(5, col);
		int row = board.buttons[0].length;
		assertEquals(5, row);
		row = board.buttons[1].length;
		assertEquals(5, row);
		row = board.buttons[2].length;
		assertEquals(5, row);
		row = board.buttons[3].length;
		assertEquals(5, row);
		row = board.buttons[4].length;
		assertEquals(5, row);
	}

	@Test
	public void testBoardSizeRow3() {
		SOSBoard board = new SOSBoard(3);
		int col = board.buttons.length;
		assertEquals(3, col);
		int row = board.buttons[0].length;
		assertEquals(3, row);
		row = board.buttons[1].length;
		assertEquals(3, row);
		row = board.buttons[2].length;
		assertEquals(3, row);
	}
	
	@Test
	public void testBoardSizeRow6() {
		SOSBoard board = new SOSBoard(6);
		int col = board.buttons.length;
		assertEquals(6, col);
		int row = board.buttons[0].length;
		assertEquals(6, row);
		row = board.buttons[1].length;
		assertEquals(6, row);
		row = board.buttons[2].length;
		assertEquals(6, row);
		row = board.buttons[3].length;
		assertEquals(6, row);
		row = board.buttons[4].length;
		assertEquals(6, row);
		row = board.buttons[5].length;
		assertEquals(6, row);
	}

}
