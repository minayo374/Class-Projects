
import javax.swing.*;


import java.awt.*;
import java.awt.event.*;

public class SOSBoard extends JPanel{
    public JButton[][] buttons;
    public JLabel currentTurnLabel ;
    public JLabel invalid;
    private int n = 3;
    private String winner = null;
    boolean isBlueS = true, isRedS = true;
    
    
	SOSBoard(int n){
		this.n = n;
		if(n <= 2) {
			invalid = new JLabel("Invalid number for board size");
		}
		setLayout(new GridLayout(n, n));
	    buttons = new JButton[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
            	buttons[i][j] = new JButton("");  // Create the buttons
            	add(buttons[i][j]);   // Add buttons to the boardPanel
                buttons[i][j].addActionListener(new ButtonListener(i, j));

            }
        }
        
        currentTurnLabel = new JLabel("Current turn: blue");
    }
	
	private class ButtonListener implements ActionListener {
        int x, y;

        ButtonListener(int i, int j) {
            this.x = i;
            this.y = j;
        }

        public void actionPerformed(ActionEvent e) {
            if (buttons[x][y].getText().equals("") && winner == null) {
                if (isBlueS) {
                    buttons[x][y].setText("S");
                }
                else if(!isBlueS) {
                	buttons[x][y].setText("O");
                }
                else if(isRedS){
                    buttons[x][y].setText("S");
                }
                else if(!isRedS) {
                	buttons[x][y].setText("O");
                }
                
                //checkForWin(x, y); // Check for win logic is not implemented in this snippet
                toggleTurn();
            }
        }
    }

	private void toggleTurn() {
        if (currentTurnLabel.getText().contains("blue")) {
            currentTurnLabel.setText("Current turn: red");
        } else {
            currentTurnLabel.setText("Current turn: blue");
        }
    }
	
}
