
import javax.swing.*;


import java.awt.*;
import java.awt.event.*;

public class SOSBoard extends JPanel{
    public JButton[][] buttons;
    public JLabel currentTurnLabel ;
    public JLabel invalid;
    private int n = 3;
    private String winner = null;
    boolean isBlueS = true, isRedS = true;
    public String currentPlayer = "blue";
    public String gameMode = "simple";
    public int bcounter = 0, rcounter = 0;
    
	SOSBoard(int n){
		this.n = n;
		if(n <= 2) {
			invalid = new JLabel("Invalid number for board size");
		}
		setLayout(new GridLayout(n, n));
	    buttons = new JButton[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
            	buttons[i][j] = new JButton("");  // Create the buttons
            	add(buttons[i][j]);   // Add buttons to the boardPanel
                buttons[i][j].addActionListener(new ButtonListener(i, j));

            }
        }
        
        currentTurnLabel = new JLabel("Current turn: blue");
    }
	
	private class ButtonListener implements ActionListener {
        int x, y;

        ButtonListener(int i, int j) {
            this.x = i;
            this.y = j;
        }

        public void actionPerformed(ActionEvent e) {
        	
            if (buttons[x][y].getText().equals("") && winner == null) {
            	if (currentPlayer.equals("blue")) {
            		if (isBlueS) {
            			buttons[x][y].setText("S");
            		}
            		else if(!isBlueS) {
            			buttons[x][y].setText("O");
            		}
            	}
            	if (currentPlayer.equals("red")) {
            		if(isRedS){
            			buttons[x][y].setText("S");
            		}
            		else if(!isRedS) {
            			buttons[x][y].setText("O");
            		}
            	}
                
                
            	checkForWin(x, y);
                toggleTurn();
            }
        }
    }

	private void toggleTurn() {
        if (currentPlayer.equals("blue")) {
            currentTurnLabel.setText("Current turn: red");
            currentPlayer = "red";
        } else {
            currentTurnLabel.setText("Current turn: blue");
            currentPlayer = "blue";
        }
    }
	

	 public void checkForWin(int x, int y) {
		 if(gameMode.equals("simple")) {
			 if (buttonCheck(buttons)) {
	            	JOptionPane.showMessageDialog(null," draw!");
	            }
	        if (checkDirection(x, y)) {
	            winner = currentPlayer;
	            JOptionPane.showMessageDialog(null, winner + " wins!");
	        }
	     }
		 if (gameMode.equals("general")) {
			 counterScore(x, y);
			 if (buttonCheck(buttons)) {
				 if(bcounter > rcounter) {
					 winner = "blue";
					 JOptionPane.showMessageDialog(null, winner + " wins!");
				 }
				 else if (bcounter == rcounter) {
					 JOptionPane.showMessageDialog(null," draw!");
				 }
				 else {
					 winner = "red";
					 JOptionPane.showMessageDialog(null, winner + " wins!");
					 }
			 }
		 }
	 }
	 
    public boolean checkDirection(int x, int y) {
        String text = buttons[x][y].getText();
        
        //if the input text is S, look for "OS" 
        if (text.equals("S")){
        	//right from input location
        	if(x + 1 < n && buttons[x + 1][y].getText().equals("O")) {
        		if(x + 2 < n && buttons[x + 2][y].getText().equals("S")) {return true;}
        	}
        	//left from input location
        	if(x - 1 < n && x - 1 >= 0 && buttons[x - 1][y].getText().equals("O")) {
        		if (x - 2 < n && x - 2 >= 0 && buttons[x - 2][y].getText().equals("S")) {return true;}
        	}
        	//top from input location
        	if(y + 1 < n && buttons[x][y + 1].getText().equals("O")) {
        		if (y + 2 < n && buttons[x][y + 2].getText().equals("S")) {return true;}
        	}
        	//down from input location
        	if (y - 1 < n && y - 1 >= 0 && buttons[x][y - 1].getText().equals("O")) {
        		if (y - 2 < n && y - 2 >= 0 && buttons[x][y - 2].getText().equals("S")) {return true;}
        	}
        	//top right from input location
        	if (x + 1 < n && y + 1 < n && buttons[x + 1][y + 1].getText().equals("O")) {
        		if (x + 2 < n && y + 2 < n && buttons[x + 2][y + 2].getText().equals("S")) {return true;}
        	}
        	//top left from input location
        	if (x - 1 < n && x - 1 >= 0 && y + 1 < n && buttons[x - 1][y + 1].getText().equals("O")) {
        		if (x - 2 < n && x - 2 >= 0 && y + 2 < n && buttons[x - 2][y + 2].getText().equals("S")) {return true;}
        	}
        	//down left from input location
        	if (x - 1 < n && x - 1 >= 0 && y - 1 < n && y - 1 >= 0 && buttons[x - 1][y - 1].getText().equals("O")) {
        		if (x - 2 < n && x - 2 >= 0 && y - 2 < n && y - 2 >= 0 && buttons[x - 2][y - 2].getText().equals("S")) {return true;}
        	}
        	//down right from input location
        	if (x + 1 < n && y - 1 < n && y - 1 >= 0 && buttons[x + 1][y - 1].getText().equals("O")) {
        		if (x + 2 < n && y - 2 < n && y - 2 >= 0 && buttons[x + 2][y - 2].getText().equals("S")) {return true;}
        	}
        }
        //if the input is look for "S"s
        else if (text.equals("O")) {
        	// x direction 
        	if (x - 1 < n && x - 1 >= 0 && buttons[x - 1][y].getText().equals("S")) {
        		if (x + 1 < n && buttons[x + 1][y].getText().equals("S")) {return true;}
        	}
        	// y direction
        	if (y + 1 < n && buttons[x][y + 1].getText().equals("S")) {
        		if (y - 1 < n && y - 1 >= 0 && buttons[x][y - 1].getText().equals("S")) {return true;}
        	}
        	//right inclination
        	if (x + 1 < n && y + 1 < n && buttons[x + 1][y + 1].getText().equals("S")) {
        		if (x - 1 < n && x - 1 >= 0 && y - 1 < n && y - 1 >= 0 && buttons[x - 1][y - 1].getText().equals("S")) {return true;}
        	}
        	//left inclination
        	if (x - 1 < n && x - 1 >= 0 && y + 1 < n && buttons[x - 1][y + 1].getText().equals("S")) {
        		if (x + 1 < n && y - 1 < n && y - 1 >= 0 && buttons[x + 1][y - 1].getText().equals("S")) {return true;}
        	}
        }
        
        return false;
    }
    
    public void counterScore(int x, int y) {
    	String text = buttons[x][y].getText();
        
        //if the input text is S, look for "OS" 
        if (text.equals("S")){
        	//right from input location
        	if(x + 1 < n && buttons[x + 1][y].getText().equals("O")) {
        		if(x + 2 < n && buttons[x + 2][y].getText().equals("S")) {
        			if (currentPlayer.equals("blue")) {bcounter++;}
        			else{rcounter++;}
        			}
        		}
        	}
        	//left from input location
        	if(x - 1 < n && x - 1 >= 0 && buttons[x - 1][y].getText().equals("O")) {
        		if (x - 2 < n && x - 2 >= 0 && buttons[x - 2][y].getText().equals("S")) {
        			if (currentPlayer.equals("blue")) {bcounter++;}
        			else{rcounter++;}
        		}
        	
        	}
        	//top from input location
        	if(y + 1 < n && buttons[x][y + 1].getText().equals("O")) {
        		if (y + 2 < n && buttons[x][y + 2].getText().equals("S")) {
        			if (currentPlayer.equals("blue")) {bcounter++;}
        			else{rcounter++;}
        			
        		}
        	}
        	//down from input location
        	if (y - 1 < n && y - 1 >= 0 && buttons[x][y - 1].getText().equals("O")) {
        		if (y - 2 < n && y - 2 >= 0 && buttons[x][y - 2].getText().equals("S")) {
        			if (currentPlayer.equals("blue")) {bcounter++;}
        			else{rcounter++;}
        		}
        	}
        	//top right from input location
        	if (x + 1 < n && y + 1 < n && buttons[x + 1][y + 1].getText().equals("O")) {
        		if (x + 2 < n && y + 2 < n && buttons[x + 2][y + 2].getText().equals("S")) {
        			if (currentPlayer.equals("blue")) {bcounter++;}
        			else{rcounter++;}
        		}
        	}
        	//top left from input location
        	if (x - 1 < n && x - 1 >= 0 && y + 1 < n && buttons[x - 1][y + 1].getText().equals("O")) {
        		if (x - 2 < n && x - 2 >= 0 && y + 2 < n && buttons[x - 2][y + 2].getText().equals("S")) {
        			if (currentPlayer.equals("blue")) {bcounter++;}
        			else{rcounter++;}
        		}
        	}
        	//down left from input location
        	if (x - 1 < n && x - 1 >= 0 && y - 1 < n && y - 1 >= 0 && buttons[x - 1][y - 1].getText().equals("O")) {
        		if (x - 2 < n && x - 2 >= 0 && y - 2 < n && y - 2 >= 0 && buttons[x - 2][y - 2].getText().equals("S")) {
        			if (currentPlayer.equals("blue")) {bcounter++;}
         			else{rcounter++;}
        		}
        	}
        	//down right from input location
        	if (x + 1 < n && y - 1 < n && y - 1 >= 0 && buttons[x + 1][y - 1].getText().equals("O")) {
        		if (x + 2 < n && y - 2 < n && y - 2 >= 0 && buttons[x + 2][y - 2].getText().equals("S")) {
        			if (currentPlayer.equals("blue")) {bcounter++;}
        			else{rcounter++;}
        		}
        	}
        	
        	 //if the input is look for "S"s
            else if (text.equals("O")) {
            	// x direction 
            	if (x - 1 < n && x - 1 >= 0 && buttons[x - 1][y].getText().equals("S")) {
            		if (x + 1 < n && buttons[x + 1][y].getText().equals("S")) {
            			if (currentPlayer.equals("blue")) {bcounter++;}
            			else{rcounter++;}
            		}
            	}
            	// y direction
            	if (y + 1 < n && buttons[x][y + 1].getText().equals("S")) {
            		if (y - 1 < n && y - 1 >= 0 && buttons[x][y - 1].getText().equals("S")) {
            			if (currentPlayer.equals("blue")) {bcounter++;}
            			else{rcounter++;}
            		}
            	}
            	//right inclination
            	if (x + 1 < n && y + 1 < n && buttons[x + 1][y + 1].getText().equals("S")) {
            		if (x - 1 < n && x - 1 >= 0 && y - 1 < n && y - 1 >= 0 && buttons[x - 1][y - 1].getText().equals("S")) {
            			if (currentPlayer.equals("blue")) {bcounter++;}
            			else{rcounter++;}
            		}
            	}
            	//left inclination
            	if (x - 1 < n && x - 1 >= 0 && y + 1 < n && buttons[x - 1][y + 1].getText().equals("S")) {
            		if (x + 1 < n && y - 1 < n && y - 1 >= 0 && buttons[x + 1][y - 1].getText().equals("S")) {
            			if (currentPlayer.equals("blue")) {bcounter++;}
            			else{rcounter++;}
            		}
            	}
            }
    }
	private boolean buttonCheck(JButton[][] bs) {
		int isFilled = 0;
		 for (int i = 0; i < n; i++) {
	            for (int j = 0; j < n; j++) {
	            	if (!bs[i][j].getText().isEmpty()) {
	            		isFilled++;
	            	}  
	            }
	        }
		 if(isFilled == n*n) {
			 return true;
		 }
		 else {return false;}
	}
}
