
public class UndirectedBruteForce {

}
